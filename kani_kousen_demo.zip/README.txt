KANIKOSEN THE GAME README DOCUMENT
**********************************

HOW TO PLAY
===========
If you're currently reading this file, you've decompressed the zip.
Congratulations! Pesky zip files can be a real pain in the ass to 
open some times. 

If you've opened the zip that means you should also see a file
lingering that goes by the name of, "main.gb" <-- This file is 
thee game!

"How does one play the game you might ask?"
And I would say, "That depends on what Operating System you have!"
In essence, depending on your OS, you will need to choose a gameboy, 
or gameboy color emulator. (If you don't know what this is, don't 
worry. It's basically just a piece of software that simulates the 
gameboy console).

I've parsed up how to play the game into the three primary OS's.
Each of which I have a recommended emulator to choose. Here we go:

Windows:
-------
bgb

 Just download bgb. It's the best. I've used it throughout development.
 If you're a geek and want to see what the actual memory looks like
 you can press the ESC key while playing and see! funfunfun

 you can find a downloadable zip for bgb at this link: http://bgb.bircd.org/
 after which you should follow their instructions on how to 
 install properly. 
 After you've installed bgb, click on it the file that ends with .exe.
 A white box should appear, and if you right click on that white box 
 with your mouse and click on "Boot ROM," a "finder" window should 
 open so that you can look through your computer and find my 
 downloaded main.gb file. It's path will likely be in 
 C:\\usr\Downloads\. or something like that. And there you have it. 
 The game should then begin.

Linux:
-----
bgb (running on wine)

 In all seriousness I've been running the bgb emulator through the wine
 emulator this whole time. Do it. Same download process as for Windows,
 just download wine first. You can find all the instructions on how to do this at https://wiki.winehq.org/Ubuntu
 
Mac OSX:
-------
I would honestly recommend running bgb through wine again, 
but I here there's a great emulator out there called openemu. 
You can download it at openemu.org

The thing is, with openemu I can't tell you what keys stand for what.
You'll have to do the research on that your self.  

*********************************************************************

The above list is just of recommendations. Use whatever emulator you
please. You just may have to do some research on your keyboard
correspond to the buttons on the GameBoy. Here's a quick How-To on 
which keyboard keys correspond to what for bgb:

KEYBOARD --> GAMEBOY KEYS
=========================
S --> A
A --> B
Then arrow keys are arrow keys. Pretty simple. Start and Select are
not used in my game, so no need to know those. 

Any way! Hopefully you've gotten the game all sorted out and are 
playing! Enjoy!

*********************************************************************
If you have any questions you can contact me at jf9260@bard.edu

Jacob Fisher
4/16/2019
