#include <gb/gb.h>
#include <gb/cgb.h>

UWORD bkg_palette[] = {
    RGB_WHITE, RGB_LIGHTGRAY, RGB_DARKGRAY, RGB_BLACK
};
