extern UWORD bkg_palette[];
