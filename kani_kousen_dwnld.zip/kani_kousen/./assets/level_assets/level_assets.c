#include "level_assets.h"

UINT8 text_count = 0;
UINT8 start_animate = 0;
UINT8 sprite_width = 8;

UINT8 hero_posx = 200;
UINT8 hero_posy = 200;
UINT8 fisherman_posx = 200;
UINT8 fisherman_posy = 200;
UINT8 miner_posx = 200;
UINT8 miner_posy = 200;
UINT8 student_posx = 200;
UINT8 student_posy = 200;
UINT8 asakawa_posx = 200;
UINT8 asakawa_posy = 200;
