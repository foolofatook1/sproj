#include <gb/gb.h>
#include <gb/cgb.h>

UWORD sprite_palette[] = {
    0, RGB_WHITE, RGB_DARKGRAY, RGB_BLACK,
    0, RGB_BLACK, RGB_DARKGRAY, RGB_WHITE,
    0, RGB_GREEN, RGB_DARKGREEN, RGB_BLACK
};
