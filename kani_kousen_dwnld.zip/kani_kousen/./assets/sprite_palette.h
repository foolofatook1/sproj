extern UWORD sprite_palette[];
