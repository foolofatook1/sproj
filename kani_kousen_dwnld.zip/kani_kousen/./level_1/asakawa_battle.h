#ifndef ASAKAWA_BATTLE_INCLUDE
#define ASAKAWA_BATTLE_INCLUDE

#include <gb/gb.h>

void asakawa_battle_ctrl(void);

#endif /* ASAKAWA_BATTLE_INCLUDE */
