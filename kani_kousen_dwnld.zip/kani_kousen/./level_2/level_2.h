#ifndef LEVEL_2_INCLUDE
#define LEVEL_2_INCLUDE

#include <gb/gb.h>
#include <gb/cgb.h>
#include "../text/assets/black_screen.h"
#include "../assets/sprite_palette.h"
#include "../assets/bkg_palette.h"
#include "../assets/sprites/hero_lie_down.h"
#include "../assets/sprites/hero_walk_sideways.h"
#include "../assets/sprites/hero_front_idle.h"
#include "../assets/sprites/fisherman_walk_sideways.h"
//#include "../assets/sprites/fisherman_walk_up.h"


void level_2_ctrl(void);
void level_2_bkg_start(void);

void l2_scene_1(void);

void joypad_check_l2_scene_1(void);
void l2_scene_1_fisherman_enter(void);
void fisherman_walk_away(void);

extern UINT8 talking;

#endif /* LEVEL_2_INCLUDE */
