#ifndef LEVEL_3_INCLUDE
#define LEVEL_3_INCLUDE

void level_3_ctrl(void);
void leaves_shit_pot(void);

#endif /* LEVEL_3_INCLUDE */
